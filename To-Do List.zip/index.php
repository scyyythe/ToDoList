<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To Do List</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="shortcut icon" href="img/icons8-to-do-50.png" type="image/x-icon">
    <link rel="stylesheet" href="css/Home.css">
</head>
<body>
    <header class="header">
        <a href="#" class="name"><strong>ToDo.</strong></a>
    
        <div class="menu">
            <a href="">Home</a>
            <a href="#about">About</a>
            <a href="login.php">Login Now</a> 
        </div>
    </header>
    
    <main>
        <div class="container">
            <div class="left-container">
                <h3>List it</h3>
                <h2>Crush It</h2>
                <p>
                   The ToDo List Management System is your ultimate productivity companion,<br> helping you effortlessly organize tasks and crush your goals.
                </p>
                <a href="login.php">
                    <button>Sign In</button>
                </a>
            </div>

            <div class="right-container">
                <img src="img/picture/TodoPic.jpg" alt="ToDo App Image">
            </div>
        </div>

        <!-- About Section -->
        <section id="about">
            <h2>About</h2>
            <h5>Welcome to Your To-Do List App! Our app is designed to help you organize your tasks efficiently, whether you’re a basic user or a premium member. Here's what you can do:</h5>
            <div class="about-features">
                <div class="feature">
                    <img src="img/add notes.png" alt="Add Notes" class="feature-image">
                    <h3>Add Notes</h3>
                    <p>Capture your thoughts and ideas quickly with our intuitive note-taking feature.</p>
                </div>
                <div class="feature">
                    <img src="img/deadline.png" alt="Set Deadlines" class="feature-image">
                    <h3>Set Deadlines</h3>
                    <p>Keep track of your tasks by setting deadlines to ensure you stay on schedule.</p>
                </div>
                <div class="feature">
                    <img src="img/add image.png" alt="Add Images" class="feature-image">
                    <h3>Add Images</h3>
                    <p>Enhance your notes with images to make your tasks more visually engaging (available for premium users).</p>
                </div>
                <div class="feature">
                    <img src="img/folder.png" alt="Organize with Folders" class="feature-image">
                    <h3>Organize with Folders</h3>
                    <p>Premium users can create folders to categorize their tasks, making it easier to manage multiple projects in one place.</p>
                </div>
            </div>

            
        </section>
    
        
    </main>

    <footer class="footer">
        <div class="footer-content">
            <div class="footer-logo">
                <h2>ToDo.</h2>
            </div>
            <ul class="footer-links">
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms of Service</a></li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">About Us</a></li>
            </ul>
            <div class="footer-social">
                <a href="#" aria-label="Facebook"><i class='bx bxl-facebook' ></i></a>
                <a href="#" aria-label="Twitter"><i class='bx bxl-twitter' ></i></a>
                <a href="#" aria-label="Instagram"><i class='bx bxl-instagram' ></i></a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 ToDo. All rights reserved.</p>
        </div>
    </footer>
    
    
</body>
</html>
